# Crash Report Summarizer App

## How to Run

1. Unzip this folder.
2. Open a terminal and navigate into the folder.
3. Run:

   pip install -r requirements.txt

4. Start the app:

   streamlit run app.py

5. Upload a crash report PDF and get a summary!

NOTE: Your OpenAI API key is stored locally in `.streamlit/secrets.toml`. Do NOT share or commit this file to GitHub.
